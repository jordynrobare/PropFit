# PropFit

Estimate group contribution values of thermodynamic properties of organic molecules. 

## Installation

Install `PropFit` with pip:

```
$ pip install propfit
```
